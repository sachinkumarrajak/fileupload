﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MVC6Crud.Data;
using MVC6Crud.Models;

namespace MVC6Crud.Controllers
{
    public class CategoryController : Controller
    {
        private readonly ApplicationDbContext _context;
        public CategoryController(ApplicationDbContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            IEnumerable<Category> categoryList = _context.Categories;
            return View(categoryList);
        }

        public IActionResult Indexnew()
        {
            IEnumerable<Category> categoryList = _context.Categories;
            return View(categoryList);
        }

        [HttpPost]
        public IActionResult FilterCategories(string[] selectedGroups)
        {
            var allCategories = _context.Categories.ToList();

            if (selectedGroups == null || selectedGroups.Length == 0)
            {
                return View("CategoryList", allCategories);
            }

            var filteredCategories = allCategories.Where(c => selectedGroups.Contains(c.Group)).ToList();

            return View("categoryList", filteredCategories);
        }
        [HttpPost]
        public IActionResult Indexsort(string[] selectedGroups)
        {
            IEnumerable<Category> categoryList = _context.Categories;

            if (selectedGroups != null && selectedGroups.Length > 0)
            {
                categoryList = categoryList.Where(c => selectedGroups.Contains(c.Group));
            }

            return View(categoryList);
        }

        public IActionResult Indexsort()
        {
            IEnumerable<Category> categoryList = _context.Categories;
            return View(categoryList);
        }

        [HttpPost]
        //public IActionResult Indexsort1(string[] selectedGroups)
        //{
        //    var categories = _context.Categories.ToList();

        //    if (selectedGroups != null && selectedGroups.Length > 0)
        //    {
        //        categories = categories.Where(c => selectedGroups.Contains(c.Group)).ToList();
        //    }

        //    ViewData["SelectedGroups"] = selectedGroups;

        //    return View("Indexsort1", categories);
        //}

        //public IActionResult Indexsort1()
        //{
        //    var categories = _context.Categories.ToList();
        //    ViewData["SelectedGroups"] = new string[0];
        //    return View(categories);
        //}

        [HttpPost]
        public IActionResult Indexsort1(string[] selectedGroups)
        {
            var categories = _context.Categories.ToList();

            if (selectedGroups != null && selectedGroups.Length > 0)
            {
                categories = categories.Where(c => selectedGroups.Contains(c.Group)).ToList();
            }

            ViewData["SelectedGroups"] = selectedGroups;

            return View("Indexsort1", categories);
        }
        public IActionResult Indexsort1()
        {
            var categories = _context.Categories.ToList();

            // Initialize or clear the selected groups for the initial view
            ViewData["SelectedGroups"] = new string[0];

            return View(categories);
        }
        [HttpPost]
        public IActionResult FilterByConnection(string[] selectedGroups, string connectionStatus)
        {
            IEnumerable<Category> categoryList = _context.Categories;

            if (selectedGroups != null && selectedGroups.Length > 0)
            {
                categoryList = categoryList.Where(c => selectedGroups.Contains(c.Group));
            }

            if (!string.IsNullOrEmpty(connectionStatus))
            {
                categoryList = categoryList.Where(c => c.ConnectionStatus == connectionStatus);
            }

            ViewData["SelectedGroups"] = selectedGroups;

            return View("Indexsort2", categoryList);
        }
        public IActionResult Indexsort2(string[] selectedGroups)
        {
            IEnumerable<Category> categoryList = _context.Categories;

            if (selectedGroups != null && selectedGroups.Length > 0)
            {
                categoryList = categoryList.Where(c => selectedGroups.Contains(c.Group));
            }

            ViewData["SelectedGroups"] = selectedGroups;

            return View(categoryList);
        }


        //public IActionResult Indexsort3(string[] selectedGroups, string searchText)
        //{
        //    IEnumerable<Category> categoryList = _context.Categories;

        //    if (!string.IsNullOrEmpty(searchText))
        //    {
        //        categoryList = categoryList.Where(c => c.CategoryName.Contains(searchText));
        //    }

        //    if (selectedGroups != null && selectedGroups.Length > 0)
        //    {
        //        categoryList = categoryList.Where(c => selectedGroups.Contains(c.Group));
        //    }

        //    ViewData["SelectedGroups"] = selectedGroups;

        //    return View(categoryList);
        //}


        public IActionResult Indexsort3(string[] selectedGroups, string searchText)
        {
            IEnumerable<Category> categoryList = _context.Categories;

            if (!string.IsNullOrEmpty(searchText))
            {
                categoryList = categoryList.Where(c => c.CategoryName.Contains(searchText) || c.ConnectionStatus.Contains(searchText));
            }

            if (selectedGroups != null && selectedGroups.Length > 0)
            {
                categoryList = categoryList.Where(c => selectedGroups.Contains(c.Group));
            }

            ViewData["SelectedGroups"] = selectedGroups;
            ViewData["SearchText"] = searchText;

            return View(categoryList);
        }
        [HttpPost]
        public IActionResult FilterByConnection2(string[] selectedGroups, string connectionStatus)
        {
            // ... (same code as before)

            IEnumerable<Category> categoryList = _context.Categories;

            if (selectedGroups != null && selectedGroups.Length > 0)
            {
                categoryList = categoryList.Where(c => selectedGroups.Contains(c.Group));
            }

            if (!string.IsNullOrEmpty(connectionStatus))
            {
                categoryList = categoryList.Where(c => c.ConnectionStatus == connectionStatus);
            }

            ViewData["SelectedGroups"] = selectedGroups;


            return View("Indexsort3", categoryList);
        }
        public IActionResult Indq()
        {
            IEnumerable<Category> categoryList = _context.Categories;
            return View(categoryList);
        }
        public IActionResult Indexnews()
        {
            IEnumerable<Category> categoryList = _context.Categories;
            return View(categoryList);
        }
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Category category)
        {
            if (ModelState.IsValid)
            {               
                _context.Categories.Add(category);
                _context.SaveChanges();
                TempData["SuccessMsg"] = "Category (" + category.CategoryName + ") added successfully.";
                return RedirectToAction("Index");
            }
            return View(category);
        }

        public IActionResult Edit(int? categoryId)
        {            
            var category = _context.Categories.Find(categoryId);

            if (category == null)
            {
                return NotFound();
            }
            return View(category);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(Category category)
        {
            if (ModelState.IsValid)
            {
                _context.Categories.Update(category);
                _context.SaveChanges();
                TempData["SuccessMsg"] = "Category (" + category.CategoryName + ") updated successfully.";
                return RedirectToAction("Index");
            }
            return View(category);
        }

        public IActionResult Delete(int? categoryId)
        {
            var category = _context.Categories.Find(categoryId);

            if (category == null)
            {
                return NotFound();
            }
            return View(category);
        }
        public IActionResult JQUERYCALL()
        {
            IEnumerable<Category> categoryList = _context.Categories;
            return View(categoryList);
        }
       
        public IActionResult JQUERYCALLPost(int? categoryId)
        {

            return Content("Hello "+ categoryId);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteCategory(int? categoryId)
        {
            var category = _context.Categories.Find(categoryId);
            if (category == null)
            {
                return NotFound();
            }
            _context.Categories.Remove(category);
            _context.SaveChanges();
            TempData["SuccessMsg"] = "Category (" + category.CategoryName + ") deleted successfully.";
            return RedirectToAction("Index");
        }

        public async Task<IActionResult> Remove(int? categoryId)
        {

            var category = _context.Categories.Find(categoryId);
            if (category == null)
            {
                return NotFound();
            }
            _context.Categories.Remove(category);
            _context.SaveChanges();
            return Json(new { success = true, message = "Delete Successful" });
        }
    }
}
