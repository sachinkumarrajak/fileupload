﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MVC6Crud.Data;

namespace MVC6Crud.Controllers
{
    public class DepartmentController : Controller
    {
        private readonly ApplicationDbContext _context;
        public DepartmentController(ApplicationDbContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Details(int id)
        {
            var department = _context.Departments
                .Include(d => d.EmployeeDepartments)
                .ThenInclude(ed => ed.Employee)
                .FirstOrDefault(d => d.ID == id);

            return View(department);
        }

    }
}
