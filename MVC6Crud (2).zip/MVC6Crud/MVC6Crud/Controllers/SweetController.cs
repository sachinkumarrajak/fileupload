﻿using Microsoft.AspNetCore.Mvc;
using MVC6Crud.Models;

namespace MVC6Crud.Controllers
{
    public class SweetController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public IActionResult SubmitData([FromBody] RegistrationModel data)
        {
            try
            {
                // Process the incoming data (data parameter) as needed
                // For example, you can save it to a database, perform calculations, etc.

                // Return a JSON response indicating success or other relevant information
                var response = new { success = true, message = "Data submitted successfully." };
                return Json(response);
            }
            catch (Exception ex)
            {
                // Handle any exceptions that occur during processing
                var errorResponse = new { success = false, message = "An error occurred." };
                return Json(errorResponse);
            }
        }
    }

    //[HttpPost]
    //public ActionResult SubmitData([FromBody] YourModelType data)
    //{
    //    try
    //    {
    //        // Process the incoming JSON data (data parameter) as needed
    //        // For example, you can save it to a database, perform calculations, etc.

    //        // Return a JSON response indicating success or other relevant information
    //        return Json(new { success = true, message = "Data submitted successfully." });
    //    }
    //    catch (Exception ex)
    //    {
    //        // Handle any exceptions that occur during processing
    //        return Json(new { success = false, message = "An error occurred." });
    //    }
    //}

}
