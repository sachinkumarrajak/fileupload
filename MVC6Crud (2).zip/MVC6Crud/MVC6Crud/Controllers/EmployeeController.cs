﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MVC6Crud.Data;
using MVC6Crud.Models;

namespace MVC6Crud.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly ApplicationDbContext _context;
        public EmployeeController(ApplicationDbContext context)
        {
            _context = context;
        }
        //public IActionResult Index()
        //{
        //    var employeesWithDepartments = _context.Employees
        //     .Include(e => e.EmployeeDepartments)
        //     .ThenInclude(ed => ed.Department)
        //     .ToList();

        //    return View(employeesWithDepartments);
        //}
        public IActionResult Index()
        {
            var employees = _context.Employees.ToList();
            return View(employees);
        }

        //public IActionResult Details(int id)
        //{
        //    var employee = _context.Employees
        //        .Include(e => e.EmployeeDepartments)
        //        .ThenInclude(ed => ed.Department)
        //        .FirstOrDefault(e => e.ID == id);

        //    return View(employee);
        //}
        public IActionResult Details(int id)
        {
            var employee = _context.Employees
                .Include(e => e.EmployeeFiles) // Include the associated files
                .FirstOrDefault(e => e.ID == id);

            if (employee == null)
            {
                return NotFound();
            }

            return View(employee);
        }


        [HttpPost]
        public async Task<IActionResult> UploadFile(int employeeId, IFormFile file)
        {
            if (file == null || file.Length == 0)
            {
                return RedirectToAction("Details", new { id = employeeId });
            }

            var fileName = Path.GetFileName(file.FileName);
            var filePath = Path.Combine("wwwroot", "uploads", fileName); // Path to the wwwroot/uploads folder

            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                await file.CopyToAsync(stream);
            }

            var employeeFile = new EmployeeFile
            {
                FileName = fileName,
                FilePath = filePath,
                EmployeeID = employeeId
            };

            _context.EmployeeFiles.Add(employeeFile);
            await _context.SaveChangesAsync();

            return RedirectToAction("Details", new { id = employeeId });
        }

        public IActionResult DownloadFile(int id)
        {
            var employeeFile = _context.EmployeeFiles.FirstOrDefault(ef => ef.ID == id);
            if (employeeFile == null)
            {
                return NotFound();
            }

            var fileStream = new FileStream(employeeFile.FilePath, FileMode.Open, FileAccess.Read);
            return File(fileStream, "application/octet-stream", employeeFile.FileName);
        }

        //[HttpPost]
        //public async Task<IActionResult> UploadFile(int employeeId, IFormFile file)
        //{
        //    if (file == null || file.Length == 0)
        //    {
        //        return RedirectToAction("Details", new { id = employeeId });
        //    }

        //    // Save the uploaded file to a directory
        //    var filePath = Path.Combine("path_to_your_file_directory", file.FileName);
        //    using (var stream = new FileStream(filePath, FileMode.Create))
        //    {
        //        await file.CopyToAsync(stream);
        //    }

        //    // Create a record in the EmployeeFile table
        //    var employeeFile = new EmployeeFile
        //    {
        //        FileName = file.FileName,
        //        FilePath = filePath,
        //        EmployeeID = employeeId
        //    };

        //    _context.EmployeeFiles.Add(employeeFile);
        //    await _context.SaveChangesAsync();

        //    return RedirectToAction("Details", new { id = employeeId });
        //}
        //public IActionResult DownloadFile(int id)
        //{
        //    var employeeFile = _context.EmployeeFiles.FirstOrDefault(ef => ef.ID == id);
        //    if (employeeFile == null)
        //    {
        //        return NotFound();
        //    }

        //    var fileStream = new FileStream(employeeFile.FilePath, FileMode.Open, FileAccess.Read);
        //    return File(fileStream, "application/octet-stream", employeeFile.FileName);
        //}

    }
}
