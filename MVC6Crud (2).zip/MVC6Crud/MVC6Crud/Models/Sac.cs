﻿using System;
using System.Collections.Generic;

namespace MVC6Crud.Models
{

    public partial class Sac
    {
        public int Id { get; set; }

        public string? Name { get; set; }
    }
    public class RegistrationModel
    {
        public List<object> Tests { get; set; }
        public List<RegTestModel> RegTest { get; set; }
        public PatientModel Patient { get; set; }
        public InvoiceModel Invoice { get; set; }
        public int Amount { get; set; }
    }

    public class RegTestModel
    {
        public int ParamID { get; set; }
        public int TestRate { get; set; }
        public string SampleCollectionDt { get; set; }
    }

    public class PatientModel
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public string AgeIn { get; set; }
        public string Sex { get; set; }
        public string Address { get; set; }
        public string PhoneNo { get; set; }
    }

    public class InvoiceModel
    {
        public int DoctorID { get; set; }
        public int Discount { get; set; }
        public string InvoiceDt { get; set; }
    }
}