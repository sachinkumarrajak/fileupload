﻿using System.ComponentModel.DataAnnotations;

namespace MVC6Crud.Models
{
    public class Category
    {
        [Key]
        public int CategoryId { get; set; }
        [Required]
        [Display(Name ="Category Name")]
        public string? CategoryName { get; set; }
        public string? Group { get; set; }
        [Required]
        [Display(Name = "Category Name")]
        public string? ConnectionStatus { get; set; }
    }
    public class Employee
    {
        public int ID { get; set; }
        public string Name { get; set; }

        public List<EmployeeFile> EmployeeFiles { get; set; }
        public List<EmployeeDepartment> EmployeeDepartments { get; set; }
        // Other properties
    }

    public class Department
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public List<EmployeeDepartment> EmployeeDepartments { get; set; }
        // Other properties
    }

    public class EmployeeDepartment
    {
        public int EmployeeID { get; set; }
        public int DepartmentID { get; set; }
        public Employee Employee { get; set; }
        public Department Department { get; set; }
    }

    public class EmployeeFile
    {
        public int ID { get; set; }
        public string FileName { get; set; }
        public string FilePath { get; set; }
        public int EmployeeID { get; set; }
        public Employee Employee { get; set; }
    }

}
