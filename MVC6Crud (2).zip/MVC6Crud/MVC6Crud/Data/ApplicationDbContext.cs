﻿using Microsoft.EntityFrameworkCore;
using MVC6Crud.Models;

namespace MVC6Crud.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<Employee> Employees { get; set; }
        public DbSet<Employee> Departments { get; set; }

        public DbSet<EmployeeFile> EmployeeFiles { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<EmployeeDepartment>()
                .HasKey(ed => new { ed.EmployeeID, ed.DepartmentID });

            modelBuilder.Entity<EmployeeDepartment>()
                .HasOne(ed => ed.Employee)
                .WithMany(e => e.EmployeeDepartments)
                .HasForeignKey(ed => ed.EmployeeID);

            modelBuilder.Entity<EmployeeDepartment>()
                .HasOne(ed => ed.Department)
                .WithMany(d => d.EmployeeDepartments)
                .HasForeignKey(ed => ed.DepartmentID);


            modelBuilder.Entity<EmployeeFile>()
           .HasOne(ef => ef.Employee)
           .WithMany(e => e.EmployeeFiles)
           .HasForeignKey(ef => ef.EmployeeID);
        }
    }
}
